#
# startup3.py - Commands for interactive session
#
# 27Jun16  Everett Lipman
#

import numpy as np
import matplotlib.pyplot as plt
